/* eslint-disable no-undef */
sap.ui.define([], function () {
    "use strict";

    return {
        formatDate: function (sDate) {
            return new Date(sDate);
        },
    }
})